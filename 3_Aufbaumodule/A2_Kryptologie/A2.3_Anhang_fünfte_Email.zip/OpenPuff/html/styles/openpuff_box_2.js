var openpuff_box_2 = '<table border="1"><tr>'+
'<td><div style="margin:10px 10px 10px 10px;">'+
'<h3><a href="./doc/OpenPuff_Help_EN.pdf"><img src="./images/flag_uk.png" alt="flag_uk.png"> Manual</a>'+
' / <a href="./doc/OpenPuff_Help_IT.pdf"><img src="./images/flag_it.png" alt="flag_it.png"> Manuale</a>'+
' / <a href="http://embeddedsw.net/doc/openpuff_steganography_and_watermarking_review.pdf"><img src="./images/pdf.jpg" alt="pdf.jpg"> Internet Review</a></h3>'+
'<h4>&nbsp;</h4>'+
'<h3><a href="http://embeddedsw.net/p2p_torrent.html"><img src="./images/torrent.jpg" alt="torrent.jpg"> Torrent</a>'+
' / <a href="./openpuff_pad.xml"><img src="./images/xml.jpg" alt="xml.jpg"> Pad</a>'+
' / <a href="./images/OpenPuff_Screenshot.jpg"><img src="./images/OpenPuff.jpg" alt="OpenPuff.jpg"> Screenshot</a>'+
' / <a href="./images/OpenPuff.jpg"><img src="./images/OpenPuff.jpg" alt="OpenPuff.jpg"> Icon</a></h3>'+
'<h4>&nbsp;</h4>'+
'<h3><a href="./doc/legal_coercion.html"><img src="./images/lambda.jpg" alt="lambda.jpg"> Legal coercion</a>'+
' / <a href="./doc/physical_coercion.txt"><img src="./images/lambda.jpg" alt="lambda.jpg"> Physical coercion</a></h3>'+
'<h4>&nbsp;</h4>'+
'<h3><a href="./doc/cypherpunk_manifesto.html"><img src="./images/lambda.jpg" alt="lambda.jpg"> Cypherpunk</a>'+
' / <a href="./doc/humans.html"><img src="./images/lambda.jpg" alt="lambda.jpg"> Humans: The Weakest Link</a></h3>'+
'<h4>&nbsp;</h4>'+
'<h3><a href="http://xkcd.com/538/"><img src="./images/security.png" alt="security.png" width="448" height="274"></a></h3>'+
'</div></td>'+
'</tr></table>';

document.write(openpuff_box_2);
var openpuff_box_1 = '<table border="1"><tr>'+
'<td><div style="margin:10px 10px 10px 10px;">'+
'<h3><b><a href="http://embeddedsw.net/zip/OpenPuff.zip"><img src="./images/zip.jpg" alt="zip.jpg"> OpenPuff</a></b>'+
' <a href="http://creativecommons.org/licenses/by/4.0/"><img src="http://i.creativecommons.org/l/by/4.0/88x31.png" alt="CC-BY 4.0" width="88" height="31"></a>'+
' / <b><a href="http://embeddedsw.net/libObfuscate_Cryptography_Home.html"><img src="./images/lambda.jpg" alt="lambda.jpg"> Source Page</a></b>'+
' / <b><a href="#tutorials"><img src="./images/lambda.jpg" alt="lambda.jpg"> Video Tutorials &amp; Youtube</a></b></h3>'+
'<h4>&nbsp;</h4>'+
'<h3><b><a href="#papers"><img src="./images/lambda.jpg" alt="lambda.jpg"> Papers &amp; Articles</a></b>'+
' / <b><a href="#thesis"><img src="./images/lambda.jpg" alt="lambda.jpg"> Thesis</a></b>'+
' / <b><a href="#lectures"><img src="./images/lambda.jpg" alt="lambda.jpg"> Lectures</a></b>'+
' / <b><a href="#reviews"><img src="./images/lambda.jpg" alt="lambda.jpg"> Web Reviews</a></b></h3>'+
'<h4>&nbsp;</h4>'+
'<h3><img src="./images/MultiObfuscator.jpg" alt="MultiObfuscator.jpg">'+
' <b>Check for more</b>: <a href="http://embeddedsw.net/Obfuscated_Storage_Home.html">Hardware</a> for <i>Independent+Deniable+Cloud</i> Data Hiding &amp; Obfuscation'+
' <img src="./images/MultiObfuscator.jpg" alt="MultiObfuscator.jpg"></h3>'+
'</div></td>'+
'</tr></table>';

document.write(openpuff_box_1);
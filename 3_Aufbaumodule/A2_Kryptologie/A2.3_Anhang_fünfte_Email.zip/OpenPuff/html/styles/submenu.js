var submenu = '<table width="95%"><tr>'+
'<td><img src="./images/embeddedsw_little.gif" alt="embeddedsw_little.gif" width="100px" height="100px"></td>'+
'<td><h4>&nbsp;</h4></td>'+
'<td valign="middle"><h1 style="font-size:30px;font-variant:small-caps;color:#FFFFC0;"><b>Advanced Embedded Solutions</b></h1>'+
'<h4>&nbsp;</h4>'+
'<h2><span style="font-variant:small-caps;"><b>S</b>ecurity - <b>S</b>oftware - <b>H</b>ardware - <b>M</b>achinery</span></h2>'+
'<h3><i>EmbeddedSW.net Project - Delivering Advanced &amp; Reliable Innovation</i></h3></td>'+
'<td><h4>&nbsp;</h4></td>'+
'<td><img src="./images/aes_little.gif" alt="aes_little.gif" width="144px" height="100px"></td>'+
'</tr></table>';

document.write(submenu);
#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Memory.py
#  

from tkinter import *


##### Parameter festlegen
# Alle Karten als Liste
moegliche_karten = ['a1', 'a2', 'b1', 'b2', 'c1', 'c2', 'd1', 'd2']

# Kartenpaare (a1 und a2 gehören zusammen)
kartenpaare = [['a1', 'a2'], ['b1', 'b2'], ['c1', 'c2'], ['d1', 'd2']]


##### Fenster zusammenbauen
# Fenster initialisieren
fenster = Tk()
fenster.title("Memory")


##### ausfuehren
fenster.mainloop()

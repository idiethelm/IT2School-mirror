var openpuff_media = '<table><tr><td>'+
'<img src="./images/OpenPuff_Screenshot.jpg" alt="OpenPuff_Screenshot.jpg" width="434" height="302">'+
'</td></tr></table>'+
'<br>'+
'<div align="justify">'+
'<a name="tutorials"></a>'+
'<h2><b>VIDEO TUTORIALS &amp; YOUTUBE</b></h2>'+
'<br>'+
'<h3>Thanks so much to the huge amount of time that people worldwide'+
' invested in creating these nice videos about OpenPuff.</h3>'+
'</div>'+
'<br>'+
'<table><tr>'+
'<td><h3><a href="http://www.youtube.com/watch?v=_2kMY0yLXcs&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">'+
'<img src="./images/openpuff_steganography_video_live_demo.jpg" alt="openpuff_steganography_video_live_demo.jpg" width="250" height="156"></a><br>'+
'<b><a href="http://www.youtube.com/watch?v=_2kMY0yLXcs&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Live Demo - EN</a></b></h3></td>'+
'<td><h3><a href="http://www.youtube.com/watch?v=NKC1COZjdto&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">'+
'<img src="./images/openpuff_steganography_video_official_demo.jpg" alt="openpuff_steganography_video_official_demo.jpg" width="250" height="156"></a><br>'+
'<b><a href="http://www.youtube.com/watch?v=NKC1COZjdto&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Video Manual - EN</a></b></h3></td>'+
'</tr></table>'+
'<br>'+
'<div align="justify">'+
'<ul>'+
'<li style="margin-left:20px;"><h3>[<i>English</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=P1I8XXlNYoA&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">AndyLuse</a>'+
' <a href="http://www.youtube.com/watch?v=B2Vxb2T9TqE&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Trovisto</a>'+
' <a href="http://www.youtube.com/watch?v=lUrr_GM6wXw&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">LabMentorsOnline</a>'+
' <b>v3.40</b>'+
' <a href="http://www.youtube.com/watch?v=C_oxICrOEe4&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">KStevens</a>'+
' <a href="http://www.youtube.com/watch?v=wBAw0bbspVM&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">PCForGeek</a>'+
' <a href="http://www.youtube.com/watch?v=h-rf7ooClEE&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">JordanGenung</a>'+
' <a href="http://www.youtube.com/watch?v=esth6Z17heM&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">TechnicDynamic</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Arabic</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=xNNwFhAzdGA&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Almohtarif</a>'+
' <a href="http://www.youtube.com/watch?v=d4r-ShrOhAQ&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">TheProfessional</a>'+
' <a href="http://www.youtube.com/watch?v=Aiil0y5k2dc&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">BouanzoulImad</a>'+
' <a href="http://www.youtube.com/watch?v=-5UxTldbZns&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Sirm07Amed</a>'+
' <a href="http://www.youtube.com/watch?v=XDFzjfdqyZw&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">IliasLahmami</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Portuguese</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=E9NDgS30fm4&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">FabricaDeNoobs</a>'+
' <a href="http://www.youtube.com/watch?v=4xRh3GCFf2U&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">HackerVid4Lok4</a>'+
' <a href="http://www.youtube.com/watch?v=2zh94_jMLWM&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">AlefCarvalho</a>'+
' <a href="http://www.youtube.com/watch?v=t7SrO2esoNs&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">HellFireHellWorld</a>'+
' <a href="http://www.youtube.com/watch?v=So5UYCsSzU8&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">SlyteTech</a>'+
' <a href="http://www.youtube.com/watch?v=z2W2xweGwuU&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">CienciaHacker</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Portuguese</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=HJfViv7qdPA&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">FabioVlm</a>'+
' <a href="http://www.youtube.com/watch?v=m6V6YnblFqI&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">AlexanderLopez</a>'+
' <a href="http://www.youtube.com/watch?v=SE-2nEBaJ0E&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">PauloVictor</a>'+
' <a href="http://www.youtube.com/watch?v=99oygWsDdn0&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">EvaldoWolkers</a>'+
' <a href="http://www.youtube.com/watch?v=mIXyva4Clpo&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">BosonTreinamentos</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Spanish</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=VYoTKvym3xY&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">EbmInformatica</a>'+
' <b>v3.30</b>'+
' <a href="http://www.youtube.com/watch?v=BcJsRzH3iAY&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Roberto De Paz</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Vietnamese</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=AtvL99w_WXQ&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">KimUyenNguyenThi</a>'+
' <a href="http://www.youtube.com/watch?v=zlAU2TF2PDo&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">BinhNguyenXuan</a>'+
' <a href="http://www.youtube.com/watch?v=bny-Dm7hzGo&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">XuanKhangVo</a>'+
' <a href="http://www.youtube.com/watch?v=Mwbq5Mk696M&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">LocPham</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>German</i>] <b>v3.40</b>'+
' <a href="http://www.youtube.com/watch?v=ts5qQmyHmYw&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">SemperVideo</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>French</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=jbhsH8vBeAQ&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">PafLeGeek</a>'+
' <b>v3.20</b>'+
' <a href="http://www.youtube.com/watch?v=rsa6YwPQIjg&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">ChaineArtupConcept</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Polish</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=XTXpa493a1o&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">Zer0Cool</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Turkish</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=ch1f-6vM4s4&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">EmreTufan-p1</a>'+
' <a href="http://www.youtube.com/watch?v=FRL4Wj-tFAw&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">EmreTufan-p2</a></h3></li>'+
'<li style="margin-left:20px;"><h3>[<i>Italian</i>] <b>v4.00</b>'+
' <a href="http://www.youtube.com/watch?v=64FmL97CtgI&amp;list=PLkEqMIqA8TUnSC4f_Km0MGUFxNhPHJsRY">WeTech</a></h3></li>'+
'</ul>'+
'</div>'+
'<br>'+
'<div align="justify">'+
'<h3>A lot of work has been published about Puff/OpenPuff since the beginning of the project, back to version 1.01 released on December 2004. Some of the'+
' following papers describe new brilliant research in the steganography/steganalysis field, that will be surely included in the upcoming versions of OpenPuff.</h3>'+
'<br>'+
'<a name="papers"></a>'+
'<h2><b>PAPERS &amp; ARTICLES</b></h2>'+
'<br>'+
'<ul>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Thwarting_audio_steganography_attacks_in_cloud_storage_systems.pdf">Thwarting audio steganography attacks in cloud storage systems</a><br>'+
'( <i>by Bo Liu, Erci Xu, Jin Wang, Ziling Wei, Liyang Xu, Baokang Zhao, Jinshu Su @ <a href="http://www.nudt.edu.cn">National University of Defense</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Steganography_analysis_efficacy_and_response_time_of_current_steganalysis_software.pdf">Steganography analysis efficacy and response time of current steganalysis software</a><br>'+
'( <i>by Jordan Green, Ian Levstein, Robert J. Boggs, Terry Fenger @ <a href="http://www.marshall.edu">Marshall University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Watermarks_an_in_depth_discussion.pdf">Watermarks an in depth discussion</a><br>'+
'( <i>by Allison Nixon @ <a href="http://www.sans.org">SANS Information Security Institute</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Digital_forensic_tools_a_comparative_approach.pdf">Digital forensic tools a comparative approach</a><br>'+
'( <i>by Dhwaniket R. Kamble, Nilakshi Jain @ <a href="http://www.shahandanchor.com">University of Mumbai</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/An_examination_on_information_hiding_tools_for_steganography.pdf">An examination on information hiding tools for steganography</a><br>'+
'( <i>by Ismail Karadogan, Resul Das @ <a href="http://www.firat.edu.tr">Firat University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Evaluation_von_heuristiken_zur_erkennung_von_kryptoroutinen_in_software.pdf">Evaluation von heuristiken zur erkennung von kryptoroutinen in software</a><br>'+
'( <i>by Felix Matenaar @ <a href="http://www.rwth-aachen.de">RWTH Aachen University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Construction_of_a_mathematical_model_to_determine_the_laws_of_statistical_characteristics_of_LSBs_wave_audio_file_format.pdf">Construction of a mathematical model to determine the laws of statistical characteristics of LSBs wave</a><br>'+
'( <i>by Irina. A. Kochevsky @ <a href="http://www.vdeunu.com">Ukranian National University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Steganography_and_desteganography_overview.pdf">Steganography and desteganography overview</a><br>'+
'( <i>by Anna A. Kukhareva @ <a href="http://conference.bmstu-kaluga.ru">Moscow State Technical University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Steganographty_in_on_line_social_networks.pdf">Steganographty in on line social networks</a><br>'+
'( <i>by Deniz A. Eminov, Selime I. Hasanova, Dragan S. Tonchev @ <a href="http://shu-bg.net">University of Shumen</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Patent_application_publication_US_2015_0047037_A1.pdf">Patent application publication US 2015/0047037 A1</a><br>'+
'( <i>by Charles Wood @ <a href="http://www.duq.edu">Duquesne University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Simulasi_algoritma_steganografi_dengan_software_openpuff.pdf">Simulasi algoritma steganografi dengan software openpuff</a><br>'+
'( <i>by Naufal A. Farauq @ <a href="http://www.polines.ac.id">Negeri Semarang University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Data_hiding_and_steganography_annual_report_2012.pdf">Data hiding and steganography annual report 2012</a><br>'+
'( <i>by Chet Hosmer @ <a href="http://www.wetstonetech.com">WetStone Technologies</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Data_hiding_exposing_concealed_data_in_multimedia_operating_systems_mobile_devices_and_network_protocols.pdf">Data hiding exposing concealed data in multimedia operating systems</a><br>'+
'( <i>by Michael Raggo, Chet Hosmer @ <a href="http://www.syngress.com">Syngress - SciTech Connect</a></i> )</h3></li>'+
'</ul>'+
'<br>'+
'<a name="thesis"></a>'+
'<h2><b>THESIS</b></h2>'+
'<br>'+
'<ul>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Investigating_steganography_in_audio_stream_for_network_forensic_investigations_detection_and_extraction.pdf">Investigating steganography in audio stream for network forensic investigations detection and extraction</a><br>'+
'( <i>by Yao Lu @ <a href="http://www.aut.ac.nz">AUT University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/StegChat_a_synonym_substitution_based_algorithm_for_text_steganography.pdf">StegChat a synonym substitution based algorithm for text steganography</a><br>'+
'( <i>by Joseph Gardiner @ <a href="http://cs.bham.ac.uk">University of Birmingham</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Stegexpose_a_tool_for_detecting_LSB_steganography.pdf">Stegexpose a tool for detecting LSB steganography</a><br>'+
'( <i>by Benedikt Boehm @ <a href="http://www.kent.ac.uk">University of Kent</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Praticas_anti_forense_um_estudo_de_seus_impactos_na_forense_computacional.pdf">Praticas anti forense um estudo de seus impactos na forense computacional</a><br>'+
'( <i>by Jadilson A. de Paiva @ <a href="http://unibratec.edu.br">University Unibratec</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Information_hiding_using_steganography_techniques_and_tools.pdf">Information hiding using steganography techniques and tools</a><br>'+
'( <i>by Asoumanaki Anna @ <a href="http://teicrete.gr">University of Crete</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Digital_forensic_in_security_of_information_system_based_on_linux_and_windows_platforms.pdf">Digital forensic in security of information system based on linux and windows platforms</a><br>'+
'( <i>by Vanja M. Korac @ <a href="http://elibrary.matf.bg.ac.rs">University of Belgrade</a></i> )</h3></li>'+
'</ul>'+
'<br>'+
'<a name="lectures"></a>'+
'<h2><b>LECTURES</b></h2>'+
'<br>'+
'<ul>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Privacy_of_communication.pdf">Privacy of communication</a> - ( <i><a href="http://www.miun.se">Mid Sweden University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Antiforensics_aka_digital_security.pdf">Antiforensics aka digital security</a> - ( <i><a href="http://www.bridgew.edu">Bridgewater State University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Information_security_survey_and_copyright_management_information_hiding.pdf">Information security survey and copyright management information hiding</a> - ( <i><a href="http://cs.cuc.edu.cn">University of China</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/An_overview_on_hiding_and_detecting_stego_data_in_video_streams.pdf">An overview on hiding and detecting stego data in video streams</a> - ( <i><a href="http://www.uva.nl">University of Amsterdam</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Securite_des_reseaux_steganographie_et_tatouage_numerique.pdf">Securite des reseaux steganographie et tatouage numerique</a> - ( <i><a href="http://www.info.univ-tours.fr">University Francois-Rabelais de Tours</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Information_security_course_shivaji.pdf">Information security course shivaji</a> - ( <i><a href="http://www.unishivaji.ac.in">Shivaji University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Tools_for_teaching_security.ppt">Tools for teaching security</a> - ( <i><a href="http://www.wku.edu">Western Kentucky University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Steganography.ppt">Steganography</a> - ( <i><a href="http://pens.ac.id">University of Surabaya</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Steganography_the_art_of_hidden_writing.pdf">Steganography the art of hidden writing</a> - ( <i><a href="http://www.cs.uml.edu">UMass Lowell University</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Workitorial_on_vision_of_the_unseen.pdf">Workitorial on vision of the unseen</a> - ( <i><a href="http://ic.unicamp.br">University of Campinas</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Cybersecurity_breakout_overview.pdf">Cybersecurity breakout overview</a> - ( <i><a href="http://maui.hawaii.edu">University of Hawai\'i Maui</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Introduccion_a_la_criptologia.pdf">Introduccion a la criptologia</a> - ( <i><a href="http://www.itesm.mx">Technical University of Monterrey</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Steganography_the_art_of_message_hiding.ppt">Steganography the art of message hiding</a> - ( <i><a href="http://www.berea.edu">Berea College</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Finding_stegomalware_in_an_ocean_of_apps.pdf">Finding stegomalware in an ocean of apps</a> - ( <i><a href="http://www.rootedcon.es">RootedCon</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Esteganografia_utilizando_o_openPuff.pdf">Esteganografia utilizando o openPuff</a> - ( <i><a href="http://fabricadenoobs.wix.com/home">Fabrica de Noobs</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/OpenPuff_steganography_and_watermarking_tool.pdf">OpenPuff steganography and watermarking tool</a> - ( <i><a href="http://www.chesbro.net">Michael Chesbro</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Gerenciamento_e_seguranca_de_dados.pdf">Gerenciamento e seguranca de dados</a> - ( <i><a href="http://wanderson.pro.br">Wanderson Reis</a></i> )</h3></li>'+
'</ul>'+
'<br>'+
'<a name="reviews"></a>'+
'<h2><b>WEB REVIEWS</b></h2>'+
'<br>'+
'<ul>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_steganography_and_amazon_cloud_drive.pdf">Steganography and amazon cloud drive</a> - ( <i><a href="http://bsmuir.kinja.com/steganography-amazon-cloud-drive-1694203958">Brent Muir</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_tools_for_the_paranoid.pdf">Tools for the paranoid</a> - ( <i><a href="http://www.pcworld.com/article/2026561/tools-for-the-paranoid-5-free-security-tools-to-protect-your-data.html">Erez Zukerman</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_best_free_steganography_program.pdf">Best free steganography program</a> - ( <i><a href="http://dottech.org/104672/windows-best-free-steganography-software-review/">Ashraf</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_keeps_files_from_prying_eyes_and_maybe_even_from_you.pdf">Keeps files from prying eyes and maybe even from you</a> - ( <i><a href="http://betanews.com/2012/07/11/openpuff-4-0-keeps-files-from-prying-eyes-and-maybe-even-from-you/">Mike Williams</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_hackers_exfiltrating_data_with_video_steganography.pdf">Hackers exfiltrating data with video steganography</a> - ( <i><a href="http://www.tripwire.com/state-of-security/incident-detection/hackers-exfiltrating-data-with-video-steganography-via-cloud-video-services/">Ken Westin</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_how_to_hide_data_in_images.pdf">How to hide data in images</a> - ( <i><a href="http://www.digit.in/general/how-to-hide-data-in-images-18934.html">Ravi Sinha</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_steganography_and_digital_watermarking_tools.pdf">Steganography and digital watermarking tools</a> - ( <i><a href="http://www.sectechno.com/steganography-and-digital-watermarking-tools/">Mourad Ben Lakhoua</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_free_encryption_and_marking_software.pdf">Free encryption and marking software</a> - ( <i><a href="http://www.ilovefreesoftware.com/24/windows/security/encryption-software-openpuff.html">Abhishek Gupta</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_steganogaphy_and_hidden_watermarks.pdf">Steganogaphy and hidden watermarks</a> - ( <i><a href="http://www.hacker10.com/computer-security/steganogaphy-and-hidden-watermarks-with-openpuff/">Hacker10</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_how_to_hide_the_computer_important_files.pdf">How to hide the computer important files</a> - ( <i><a href="http://www.ppcn.net/32966.html">Ppcn</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_tecniche_e_strumenti_di_antiforensics.pdf">Tecniche e strumenti di antiforensics</a> - ( <i><a href="https://www.david-tanzer.com/anti-computer-forensics">Wiliam David Tanzer</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_la_steganografia_comunicare_come_una_spia.pdf">La steganografia comunicare come una spia</a> - ( <i><a href="http://www.spiare.com/blog/la-steganografia-comunicare-come-una-spia/">ZioGeek</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_la_steganografia_in_pratica.pdf">La steganografia in pratica</a> - ( <i><a href="http://tecnologichevolmente.com/la-steganografia-in-pratica/">Tecnologichevolmente</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_nascondere_documenti_in_un_immagine.pdf">Nascondere documenti in un immagine</a> - ( <i><a href="http://www.ilsoftware.it/articoli.asp?tag=Nascondere-documenti-in-un-immagine-o-in-altri-tipi-di-file-con-OpenPuff_8972">Michele Nasi</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_la_esteganografia_el_viajero_oculto_de_la_criptologia.pdf">La esteganografia el viajero oculto de la criptologia</a> - ( <i><a href="http://www.palentino.es/blog/la-esteganografia-el-viajero-oculto-de-la-criptologia-historia-aplicada-a-la-informatica-casos-practicos/">Oscar de la Cuesta</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_o_que_e_esteganografia.pdf">O que e esteganografia</a> - ( <i><a href="http://www.bosontreinamentos.com.br/seguranca/o-que-e-esteganografia/">Fabio dos Reis</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_camufla_archivos_detras_de_otros_archivos.pdf">Camufla archivos detras de otros archivos</a> - ( <i><a href="http://computerhoy.com/paso-a-paso/software/camufla-archivos-detras-otros-archivos-26203">Ruben Andres</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_esteganografia_oculta_archivos.pdf">Esteganografia oculta archivos</a> - ( <i><a href="http://xenodesystems.blogspot.it/2012/07/esteganografia-oculta-archivos-en.html">Manuel Escudero</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_macht_dateien_praktisch_unauffindbar.pdf">Macht dateien praktisch unauffindbar</a> - ( <i><a href="http://www.krone.at/Digital/OpenPuff_macht_Dateien_praktisch_unauffindbar-Geheimer_geht_nicht-Story-351597">KronenZeitung</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_was_ist_steganographie.pdf">Was ist steganographie</a> - ( <i><a href="https://kowabit.de/steganographie/">Kowabit</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_steganographie.pdf">Steganographie</a> - ( <i><a href="http://realasmodis.blog.de/2012/04/15/steganographie-13511019/">Realasmodis</a></i> )</h3></li>'+
'<li style="margin-left:20px;"><h3><a href="http://embeddedsw.net/doc/Openpuff_review_szteganografia.pdf">Szteganografia</a> - ( <i><a href="http://pcworld.hu/szoftver/szteganografia-lathatatlan-fajlok.html">Meszaros Csaba</a></i> )</h3></li>'+
'</ul>'+
'<br>'+
'<h2><b>JUNK</b></h2>'+
'<br>'+
'<ul>'+
'<li style="margin-left:20px;"><h3>"<i>Forensic analysis of video steganography tools</i>", Thomas Sloan, Julio Hernandez-Castro<br>easy-buck effort to <b>recycle</b> of the well-known work from <a href="http://www.guillermito2.net/stegano/index.html">Guillermito</a></h3></li>'+
'<li style="margin-left:20px;"><h3>"<i>Steganalysis of openpuff through atomic concatenation of MP4 flags</i>", Thomas Sloan, Julio Hernandez-Castro<br>malicious <b>trash</b> written after calling the Author on Skype asking: "How does it work on MP4?"</h3></li>'+
'</ul>'+
'</div>';

document.write(openpuff_media);